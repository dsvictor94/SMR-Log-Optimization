#!/bin/sh

echo ""
echo "To have a leader, please run a zookeeper instance!"
echo ""
